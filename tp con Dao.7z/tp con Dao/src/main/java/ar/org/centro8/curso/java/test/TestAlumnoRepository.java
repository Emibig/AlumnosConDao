package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.AlumnoRepository;

public class TestAlumnoRepository {
	public static void main(String[] args) {
		
		I_AlumnoRepository cr=new AlumnoRepository();
		
		System.out.println("-- save() --");
		Alumno alumno=new Alumno("Luz","Maria",30,6);
		cr.save(alumno);
		System.out.println(alumno);		
		
		System.out.println("-- remove() --");
		cr.remove(cr.getById(11));		
		
		System.out.println("-- getAll() --");
		cr.getAll().forEach(System.out::println);
		
		
		System.out.println("-- getLikeNombreAndIdCurso() --");
		cr.getLikeNombreAndIdCurso(1,"Juan").forEach(System.out::println);
		
	}
}
