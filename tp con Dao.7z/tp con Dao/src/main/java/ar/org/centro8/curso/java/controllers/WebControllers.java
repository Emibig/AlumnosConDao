package ar.org.centro8.curso.java.controllers;


import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.jdbc.AlumnoRepository;

@Controller
public class WebControllers {

    @GetMapping("/")
    public String getIndex() {
        return "index";
    }

    @GetMapping("/alumnos")
    public String getAlumnos() {

        return "alumnos";
    }

    
    @GetMapping("/cursos")
    public String getCursos() {
        return "cursos";
    }
}
